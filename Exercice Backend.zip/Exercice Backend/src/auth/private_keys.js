module.exports = 'CUSTOM_PRIVATE_KEY'
